??MONSTERBOT �SCAR??, [14.08.16 12:41]
-- by @Blackwolf_admin 
do 
local function pre_process(msg) 
 local hash = 'muteall:'..msg.to.id 
  if redis:get(hash) and msg.to.type == 'channel' and not is_momod(msg)  then 
   delete_msg(msg.id, ok_cb, false) 
       end 
    return msg 
 end 
local function run(msg, matches) 
 if matches[1] == 'muteall' and is_momod(msg) then 
       local hash = 'muteall:'..msg.to.id 
       if not matches[2] then 
              redis:set(hash, true) 
             return "mute all has been enabled" 
 else 
-- by @Blackwolf_admin 
local hour = string.gsub(matches[2], 'h', '') 
 local num1 = tonumber(hour) * 3600 
local minutes = string.gsub(matches[3], 'm', '') 
 local num2 = tonumber(minutes) * 60 
local second = string.gsub(matches[4], 's', '') 
 local num3 = tonumber(second) 
local num4 = tonumber(num1 + num2 + num3) 
redis:setex(hash, num4, true) 
 return "mute all has been enabled for\n? hour(s) : "..matches[2].."\n? minute(s) : "..matches[3].." \n? second(s) : "..matches[4].."" 
 end 
 end 
if matches[1] == 'unmuteall' and is_momod(msg) then 
               local hash = 'muteall:'..msg.to.id 
        redis:del(hash) 
          return "mute all has been disabled" 
  end 
end 
return { 
   patterns = { 
      '^[/!#](muteall)$', 
      '^[/!#](unmuteall)$', 
   '^[/!#](muteall) (.*) (.*) (.*)$', 
 }, 
run = run, 
  pre_process = pre_process 
} 
end 
-- by @Blackwolf_admin

??MONSTERBOT �SCAR??, [14.08.16 14:20]
--[[ 
�_ _��__��__��__��__��__��__��_�__��__��__��__�� 
�_ _�                                      �_ _� 
�_ ????? ???? ????????? 
      #CODS CREATED By ~ @JALAL_ALDON 
      please join to Channel Oscar Team @OSCARBOTv2 
�_ _�                                      �_ _� 
�_��__��__�__��__��__�__��__��__�__��__��__�__�� 
--]] 
do 

local function pre_process(msg) 
local jalal = msg['id'] 
    local oscar = 'matepp:'..msg.to.id 
    if redis:get(oscar) and msg.fwd_from and not is_momod(msg) then 
            delete_msg(msg.id, ok_cb, true) 
            delete_msg(msg.id, ok_cb, true) 
            delete_msg(msg.id, ok_cb, true) 
            local don = " ??????? : "..msg.from.first_name.."".."\n".."?????? ????? ????? ?????".."\n".."??????? ??????????? ".."\n".."?? ?? : @"..(msg.from.username or " ") 
reply_msg(jalal, don, ok_cb, true) 
        end 

        return msg 
    end 

local function run(msg, matches) 
local jalal = msg['id'] 
    chat_id =  msg.to.id 
--by @JALAL_ALDON 
    if matches[1] == 'warn' and matches[2] == "fwd" and is_momod(msg) then 
                    local oscar = 'mateppp:'..msg.to.id 
                    redis:set(oscar, true) 
                    local jd = '?? ??? ????? ????? ?? ????? {??}??' -- By @JALAL_ALDON 
reply_msg(jalal, jd, ok_cb, true) 
elseif matches[1] == 'warn' and matches[2] == 'fwd' and not is_momod(msg) then 
local asdy = '???????? ??? ???????' 
reply_msg(jalal, asdy, ok_cb, true) 

    elseif matches[1] == 'unwarn' and matches[2] == 'fwd' and is_momod(msg) then 
      local oscar = 'mateppp:'..msg.to.id 
      redis:del(oscar) 
    local don = ' ?? ????? ??? ????? ????? ?? ????? {?}??' --by @JALAL_ALDON 
reply_msg(jalal, don, ok_cb, true) 
elseif matches[1] == 'unwarn' and matches[2] == 'fwd' and not is_momod(msg) then 
local jalal_aldon = '???????? ??? ????? ??' 
reply_msg(jalal, jalal_aldon, ok_cb, true) 
end 
end 

return { 
    patterns = { 
        '^[!/#](warn) (.*)$', 
       '^[!/#](unwarn) (.*)$' 
    }, 
    run = run, 
    pre_process = pre_process 
} 

-- By @JALAL_ALDON 
end