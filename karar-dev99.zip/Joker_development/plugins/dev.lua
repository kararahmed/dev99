--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY karar                          ▀▄ ▄▀ 
▀▄ ▄▀     BY karar       (@kr_2p_bot)      ▀▄ ▄▀ 
▀▄ ▄▀                                      ▀▄ ▄▀   
▀▄ ▄▀       broadcast  : رساله خاصه          ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]
do 
function run(msg, matches)
return [[

االبوت الذي يعمل على مجوعات السوبر فقط 🔸�

     ≪تم صنع البوت بواسطة المطور≫
 karar ahmed 
 @kr_2p
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"مطور البوت$",

},
run = run 
}
end
