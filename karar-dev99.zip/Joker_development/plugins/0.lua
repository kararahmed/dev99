do --@Oo_dev_lua_oO
function ibrahim(msg, matches)
  if matches[1] == "تنشيط" and is_sudo(msg) then
    return os.execute("./launch.sh"):read('*all')
  elseif matches[1] == "تحديث" and is_sudo(msg) then
     return io.popen("git pull"):read('*all')
  elseif  matches[1] == "تنضيف" and is_sudo(msg) then 
    return io.popen("redis-server"):read('*all')
  end
end --@api_dev_cli
return {
  patterns = {
    "^(تنشيط)",
    "^(تحديث)",
    "^(تنضيف)"
  },
  run = ibrahim
}
end
--@Oo_dev_lua_oO
--@api_dev_cli