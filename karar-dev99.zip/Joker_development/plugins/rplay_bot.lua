--[[
# For More Information ....! 
# Developer : Aziz < @devss_bot >      #Dev
# our channel: @help_tele
]]
do 

local function run(msg, matches) 

if ( msg.text ) then

  if ( msg.to.type == "user" ) then

     return "اذا تريد بوت يحمي مجموعتك وباوامر عربيه تعال اهنا (@KR_2P)كروب الدعم زيادات بشده تعال اهنا https://telegram.me/joinchat/CKiPgUBW0CMcR3gDYZxpKA"
     
  end 
   
end 

-- #DEV KARAR AHMED

end 

return { 
  patterns = { 
       "(.*)$"
  }, 
  run = run, 
} 

end 