rocks_trees = {
   { name = [[system]], root = [[/home/ubuntu/workspace/Joker_development/.luarocks]] }
}
