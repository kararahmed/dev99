قنــــــــــــــــــــاة الســورس
# [help_telp](https://telegram.me/help_telp)


*******************************************************************
```sh

# Let's install the bot.
افتـح ترمنـــأل وخلي 👇🏿 Open Terminal and vinegary

sudo apt-get update 

ورهأَ خلي 👇🏿 And vinegary

redis-server
تركه مفتوح✋🏿  Leave it open Terminal

وفتح ترمنال ثاني وخلي 👇🏿 Open Terminal and second vinegary
************************************************************
sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev libjansson* libpython-dev make unzip git redis-server g++ -y --force-yes
************************************************************
ورأهأَ خلي👇🏿
**************
git clone https://github.com/Joker-development/Joker_development.git
*****************************************************
ورهأ خلي 👇🏿 And vinegary
**************************
cd Joker_development
**************************
ورهأَ خلي👇🏿 And vinegary
**************************
chmod +x launch.sh
**************************
ورهأَ خلي👇🏿 And vinegary
**************************
./launch.sh install
**************************
ورهأَ خلي👇🏿 And vinegary
**************************
./launch.sh 
**************************
يطلب رقم خلي رقم البوت ✋🏿😘
مبروك عليك افضل بوت عل تلي 😍

# Enter a phone number & confirmation code.
Congratulations, you better bot
```
### One command
To install everything in one command (useful for VPS deployment) on Debian-based distros, use:

لتنصيب البوـب بكوَدَ واحد فقط َ ✋🏿😘👇🏿 To install one code

فتح ترمنال وخلي 👇🏿 Open Terminal and vinegary
*******************
sudo apt-get update 
*******************
ورهأَ خلي 👇🏿 And vinegary
*******************
redis-server
*******************
تركه مفتوح✋🏿 Leave it open Terminal

وفتح ترمنال ثاني وخلي 👇🏿 Open Terminal and second vinegary
```sh

sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev libjansson* libpython-dev make unzip git redis-server g++ -y --force-yes && git clone https://github.com/Joker-development/Joker_development.git && cd Joker_development && chmod +x launch.sh && ./launch.sh install && ./launch.sh
```

* * *
يطلب رقم خلي رقم البوت ✋🏿😘
مبروك عليك افضل بوت عل تلي 😍

# Enter a phone number & confirmation code.
Congratulations, you better bot

### Realm configuration

After you run the bot for first time, send it `!id`. Get your ID and stop the bot.

Open ./data/config.lua and add your ID to the "sudo_users" section in the following format:
✋🏿 لتصبح مطور بوتك غير الايدي خاص كونفج بايديك 👇🏿
```
  sudo_users = {
    190385827,
    0,
    YourID
  }
```
😘 مـبروَك أصبَحتـَ مـطورَ بوـتكَ لتوأصل معي 

#Dev : [@fuck_8_you](https://telegram.me/fuck_8_you)
#Dev_BOT :  [@devss_bot](https://telegram.me/devss_bot)
#Dev_Channel :  [@help_telp](https://telegram.me/help_telp)

عندكَ فكره تطوير السورس او البوت تفظل هنأَ☝🏿️
You have an idea to develop Alsoors or bot prefer ☝🏿️✋🏿
